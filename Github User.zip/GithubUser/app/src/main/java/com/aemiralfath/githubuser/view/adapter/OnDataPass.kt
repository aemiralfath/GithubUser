package com.aemiralfath.githubuser.view.adapter

interface OnDataPass {
    fun onDataPass(username: String)
}